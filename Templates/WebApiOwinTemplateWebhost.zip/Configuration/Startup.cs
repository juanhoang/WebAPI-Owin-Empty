﻿using Microsoft.Owin;
using Owin;
using $safeprojectname$.Configuration;

[assembly:OwinStartup(typeof(Startup))]

namespace $safeprojectname$.Configuration
{
    public class Startup
    {
        public void Configuration(IAppBuilder appBuilder)
        {
            appBuilder.UseWebApi(WebApiConfig.Register());
        }
    }
}
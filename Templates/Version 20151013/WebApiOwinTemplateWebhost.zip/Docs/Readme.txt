﻿Template description

Rabbit WebAPI Recommended Template

##Requirements
1. Provide a minimum template for WebAPI project that does not depend on System.Web
2. Provide a version machanism that works on multiple versions of API sets

## Setup

1. Packages
- Install-Package Microsoft.AspNet.WebApi.Owin
- Install-Package Microsoft.Owin.Host.SystemWeb

2. Code
- A startup class
- A method to create HttpConfiguration
- A demo controller


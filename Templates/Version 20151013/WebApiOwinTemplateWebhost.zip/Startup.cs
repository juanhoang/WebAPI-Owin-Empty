﻿using Microsoft.Owin;
using Owin;
using $safeprojectname$;
using $safeprojectname$.Configuration;

[assembly: OwinStartup(typeof(Startup))]

namespace $safeprojectname$
{
    public class Startup
    {
        public void Configuration(IAppBuilder appBuilder)
        {
            var configuration = WebApiConfig.Register();

            //  Register an IOC
            configuration.RegisterDependencyResolver();

            appBuilder.UseWebApi(configuration);
        }
    }
}